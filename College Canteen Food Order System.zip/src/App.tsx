import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { HomePage } from "./components/HomePage";
import { MenuPage } from "./components/MenuPage";
import { AboutPage } from "./components/AboutPage";
import { CartPage } from "./components/CartPage";
import { OrdersPage } from "./components/OrdersPage";
import { Toaster } from "sonner@2.0.3";

interface FoodItem {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  description: string;
  isVeg: boolean;
  spiceLevel?: 'mild' | 'medium' | 'hot';
}

interface CartItem extends FoodItem {
  quantity: number;
}

interface Order {
  id: string;
  items: CartItem[];
  customerInfo: any;
  paymentMethod: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  orderTime: string;
  status: 'pending' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
}

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('campus-canteen-cart');
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    }
    
    const savedOrders = localStorage.getItem('campus-canteen-orders');
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('campus-canteen-cart', JSON.stringify(cartItems));
  }, [cartItems]);

  // Save orders to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('campus-canteen-orders', JSON.stringify(orders));
  }, [orders]);

  const handleAddToCart = (item: FoodItem) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(cartItem => cartItem.id === item.id);
      
      if (existingItem) {
        return prevItems.map(cartItem =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      } else {
        return [...prevItems, { ...item, quantity: 1 }];
      }
    });
  };

  const handleUpdateQuantity = (id: number, quantity: number) => {
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (id: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== id));
  };

  const handlePlaceOrder = (orderData: any) => {
    const newOrder: Order = {
      ...orderData,
      id: `ORD-${Date.now().toString().slice(-6)}`,
      status: 'pending'
    };
    
    setOrders(prevOrders => [newOrder, ...prevOrders]);
    setCartItems([]); // Clear cart after successful order
    setCurrentPage('orders'); // Navigate to orders page
  };

  const cartItemsCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onPageChange={setCurrentPage} />;
      case 'menu':
        return <MenuPage onAddToCart={handleAddToCart} />;
      case 'about':
        return <AboutPage />;
      case 'cart':
        return (
          <CartPage
            cartItems={cartItems}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveItem}
            onPlaceOrder={handlePlaceOrder}
          />
        );
      case 'orders':
        return <OrdersPage orders={orders} />;
      default:
        return <HomePage onPageChange={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        cartItemsCount={cartItemsCount}
      />
      {renderCurrentPage()}
      <Toaster position="top-right" />
    </div>
  );
}
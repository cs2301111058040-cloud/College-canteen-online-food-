import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Plus, Star, Filter } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface FoodItem {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  description: string;
  isVeg: boolean;
  spiceLevel?: 'mild' | 'medium' | 'hot';
}

interface MenuPageProps {
  onAddToCart: (item: FoodItem) => void;
}

export function MenuPage({ onAddToCart }: MenuPageProps) {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const menuItems: FoodItem[] = [
    {
      id: 1,
      name: "Special Thali",
      price: 85,
      image: "https://images.unsplash.com/photo-1756741987051-a6a38f28838b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmb29kJTIwdGhhbGklMjByaWNlJTIwY3Vycnl8ZW58MXx8fHwxNzU5MDE0NTk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "main-course",
      rating: 4.5,
      description: "Complete meal with rice, dal, vegetables, roti, and pickle",
      isVeg: true,
      spiceLevel: 'medium'
    },
    {
      id: 2,
      name: "Masala Dosa",
      price: 65,
      image: "https://images.unsplash.com/photo-1708146464361-5c5ce4f9abb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb3NhJTIwc291dGglMjBpbmRpYW4lMjBicmVha2Zhc3R8ZW58MXx8fHwxNzU5MDE0NTk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "breakfast",
      rating: 4.7,
      description: "Crispy dosa with spiced potato filling, served with sambar and chutney",
      isVeg: true,
      spiceLevel: 'mild'
    },
    {
      id: 3,
      name: "Chicken Biryani",
      price: 120,
      image: "https://images.unsplash.com/photo-1666190092689-e3968aa0c32c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXJ5YW5pJTIwcmljZSUyMGRpc2h8ZW58MXx8fHwxNzU4OTk0NzY3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "main-course",
      rating: 4.8,
      description: "Aromatic basmati rice with tender chicken and traditional spices",
      isVeg: false,
      spiceLevel: 'hot'
    },
    {
      id: 4,
      name: "Samosa (2 pcs)",
      price: 25,
      image: "https://images.unsplash.com/photo-1697155836252-d7f969108b5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW1vc2ElMjBpbmRpYW4lMjBzbmFja3N8ZW58MXx8fHwxNzU5MDE0NTk5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "snacks",
      rating: 4.3,
      description: "Crispy triangular pastries filled with spiced potatoes and peas",
      isVeg: true,
      spiceLevel: 'mild'
    },
    {
      id: 5,
      name: "Masala Chai",
      price: 15,
      image: "https://images.unsplash.com/photo-1648192312898-838f9b322f47?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGFpJTIwdGVhJTIwaW5kaWFufGVufDF8fHx8MTc1OTAxNDU5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "beverages",
      rating: 4.6,
      description: "Traditional Indian spiced tea with milk and aromatic spices",
      isVeg: true
    },
    {
      id: 6,
      name: "Veg Pulao",
      price: 70,
      image: "https://images.unsplash.com/photo-1756741987051-a6a38f28838b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmb29kJTIwdGhhbGklMjByaWNlJTIwY3Vycnl8ZW58MXx8fHwxNzU5MDE0NTk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "main-course",
      rating: 4.2,
      description: "Fragrant rice cooked with mixed vegetables and spices",
      isVeg: true,
      spiceLevel: 'medium'
    },
    {
      id: 7,
      name: "Plain Dosa",
      price: 45,
      image: "https://images.unsplash.com/photo-1708146464361-5c5ce4f9abb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb3NhJTIwc291dGglMjBpbmRpYW4lMjBicmVha2Zhc3R8ZW58MXx8fHwxNzU5MDE0NTk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "breakfast",
      rating: 4.4,
      description: "Simple crispy dosa served with sambar and coconut chutney",
      isVeg: true
    },
    {
      id: 8,
      name: "Coffee",
      price: 20,
      image: "https://images.unsplash.com/photo-1648192312898-838f9b322f47?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGFpJTIwdGVhJTIwaW5kaWFufGVufDF8fHx8MTc1OTAxNDU5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "beverages",
      rating: 4.1,
      description: "Fresh brewed filter coffee with milk and sugar",
      isVeg: true
    }
  ];

  const categories = [
    { id: 'all', name: 'All Items' },
    { id: 'breakfast', name: 'Breakfast' },
    { id: 'main-course', name: 'Main Course' },
    { id: 'snacks', name: 'Snacks' },
    { id: 'beverages', name: 'Beverages' }
  ];

  const filteredItems = selectedCategory === 'all' 
    ? menuItems 
    : menuItems.filter(item => item.category === selectedCategory);

  const handleAddToCart = (item: FoodItem) => {
    onAddToCart(item);
    toast.success(`${item.name} added to cart!`);
  };

  const getSpiceLevelColor = (level?: string) => {
    switch (level) {
      case 'mild': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hot': return 'bg-red-100 text-red-800';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Our Menu</h1>
          <p className="text-lg text-gray-600">Discover our delicious selection of authentic Indian food</p>
        </div>

        {/* Category Filter */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="w-5 h-5 text-gray-500" />
            <span className="font-medium text-gray-700">Filter by Category:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className="rounded-full"
              >
                {category.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Menu Items Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <ImageWithFallback
                  src={item.image}
                  alt={item.name}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-2 left-2 flex gap-1">
                  <Badge variant={item.isVeg ? "secondary" : "destructive"} className="text-xs">
                    {item.isVeg ? "VEG" : "NON-VEG"}
                  </Badge>
                  {item.spiceLevel && (
                    <Badge className={`text-xs ${getSpiceLevelColor(item.spiceLevel)}`}>
                      {item.spiceLevel.toUpperCase()}
                    </Badge>
                  )}
                </div>
                <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <span className="text-sm font-medium">{item.rating}</span>
                </div>
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">{item.name}</h3>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{item.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold text-primary">₹{item.price}</span>
                  <Button
                    size="sm"
                    onClick={() => handleAddToCart(item)}
                    className="flex items-center gap-1"
                  >
                    <Plus className="w-4 h-4" />
                    Add
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg text-gray-500">No items found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
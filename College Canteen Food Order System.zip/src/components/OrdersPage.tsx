import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { Clock, MapPin, Package, CheckCircle, AlertCircle } from "lucide-react";

interface Order {
  id: string;
  items: any[];
  customerInfo: any;
  paymentMethod: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  orderTime: string;
  status: 'pending' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
}

interface OrdersPageProps {
  orders: Order[];
}

export function OrdersPage({ orders }: OrdersPageProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'preparing': return 'bg-blue-100 text-blue-800';
      case 'ready': return 'bg-green-100 text-green-800';
      case 'delivered': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'preparing': return <Package className="w-4 h-4" />;
      case 'ready': return <CheckCircle className="w-4 h-4" />;
      case 'delivered': return <CheckCircle className="w-4 h-4" />;
      case 'cancelled': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getEstimatedTime = (status: string, orderTime: string) => {
    const orderDate = new Date(orderTime);
    const now = new Date();
    const elapsed = Math.floor((now.getTime() - orderDate.getTime()) / (1000 * 60));
    
    switch (status) {
      case 'pending':
        return 'Processing order...';
      case 'preparing':
        const remaining = Math.max(0, 15 - elapsed);
        return remaining > 0 ? `Ready in ${remaining} minutes` : 'Ready soon';
      case 'ready':
        return 'Ready for pickup/delivery';
      case 'delivered':
        return 'Order completed';
      case 'cancelled':
        return 'Order cancelled';
      default:
        return '';
    }
  };

  // Mock orders if empty
  const displayOrders = orders.length > 0 ? orders : [
    {
      id: 'ORD-001',
      items: [
        { id: 1, name: 'Special Thali', price: 85, quantity: 1, isVeg: true },
        { id: 2, name: 'Masala Chai', price: 15, quantity: 2, isVeg: true }
      ],
      customerInfo: {
        name: 'John Doe',
        phone: '+91 98765 43210',
        studentId: 'CS2021001',
        deliveryLocation: 'pickup'
      },
      paymentMethod: 'cash',
      subtotal: 115,
      deliveryFee: 0,
      total: 115,
      orderTime: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
      status: 'preparing' as const
    },
    {
      id: 'ORD-002',
      items: [
        { id: 3, name: 'Chicken Biryani', price: 120, quantity: 1, isVeg: false }
      ],
      customerInfo: {
        name: 'Jane Smith',
        phone: '+91 87654 32109',
        studentId: 'ME2020045',
        deliveryLocation: 'library'
      },
      paymentMethod: 'upi',
      subtotal: 120,
      deliveryFee: 20,
      total: 140,
      orderTime: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
      status: 'delivered' as const
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">My Orders</h1>
        
        {displayOrders.length === 0 ? (
          <div className="text-center py-16">
            <Package className="w-24 h-24 text-gray-300 mx-auto mb-6" />
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">No orders yet</h2>
            <p className="text-gray-600 mb-6">Place your first order to see it here!</p>
            <Button onClick={() => window.history.back()}>
              Browse Menu
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {displayOrders.map((order) => (
              <Card key={order.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Order #{order.id}</CardTitle>
                    <Badge className={getStatusColor(order.status)}>
                      <div className="flex items-center gap-1">
                        {getStatusIcon(order.status)}
                        <span className="capitalize">{order.status}</span>
                      </div>
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {new Date(order.orderTime).toLocaleString()}
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {order.customerInfo.deliveryLocation === 'pickup' 
                        ? 'Pickup from Canteen' 
                        : `Deliver to ${order.customerInfo.deliveryLocation}`}
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Status & Time */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-900">
                        {getEstimatedTime(order.status, order.orderTime)}
                      </span>
                      {order.status === 'ready' && (
                        <Button size="sm">
                          Mark as Picked Up
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Order Items */}
                  <div>
                    <h4 className="font-medium mb-3">Order Items</h4>
                    <div className="space-y-2">
                      {order.items.map((item, index) => (
                        <div key={index} className="flex items-center justify-between py-2">
                          <div className="flex items-center gap-2">
                            <Badge variant={item.isVeg ? "secondary" : "destructive"} className="text-xs">
                              {item.isVeg ? "V" : "N"}
                            </Badge>
                            <span>{item.name}</span>
                            <span className="text-gray-500">x{item.quantity}</span>
                          </div>
                          <span className="font-medium">₹{item.price * item.quantity}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Order Total */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal</span>
                      <span>₹{order.subtotal}</span>
                    </div>
                    {order.deliveryFee > 0 && (
                      <div className="flex justify-between text-sm">
                        <span>Delivery Fee</span>
                        <span>₹{order.deliveryFee}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-semibold">
                      <span>Total</span>
                      <span>₹{order.total}</span>
                    </div>
                  </div>

                  {/* Customer Info */}
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-gray-600">Customer:</span>
                        <span className="ml-2 font-medium">{order.customerInfo.name}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Phone:</span>
                        <span className="ml-2">{order.customerInfo.phone}</span>
                      </div>
                      {order.customerInfo.studentId && (
                        <div>
                          <span className="text-gray-600">Student ID:</span>
                          <span className="ml-2">{order.customerInfo.studentId}</span>
                        </div>
                      )}
                      <div>
                        <span className="text-gray-600">Payment:</span>
                        <span className="ml-2 capitalize">{order.paymentMethod}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" size="sm">
                      Reorder
                    </Button>
                    <Button variant="outline" size="sm">
                      View Receipt
                    </Button>
                    {order.status === 'pending' && (
                      <Button variant="destructive" size="sm">
                        Cancel Order
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
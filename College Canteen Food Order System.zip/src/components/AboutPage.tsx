import { Card, CardContent } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Clock, MapPin, Phone, Mail, Users, Award, Heart } from "lucide-react";

export function AboutPage() {
  const stats = [
    { icon: Users, label: "Happy Students", value: "5000+" },
    { icon: Award, label: "Years of Service", value: "15+" },
    { icon: Heart, label: "Daily Orders", value: "500+" }
  ];

  const hours = [
    { day: "Monday - Friday", time: "7:00 AM - 9:00 PM" },
    { day: "Saturday", time: "8:00 AM - 8:00 PM" },
    { day: "Sunday", time: "8:00 AM - 6:00 PM" }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-6">
                About Campus Canteen
              </h1>
              <p className="text-lg text-gray-600 mb-6">
                For over 15 years, Campus Canteen has been serving delicious, affordable, and 
                nutritious meals to students and faculty. Our mission is to provide fresh, 
                authentic Indian cuisine that feels like home-cooked food.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                We understand the busy life of students, which is why we've created an online 
                ordering system that makes it easy to get your favorite meals quickly without 
                compromising on quality or taste.
              </p>
              
              {/* Stats */}
              <div className="grid grid-cols-3 gap-6">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <stat.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1725352118061-3da248f1826d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwY2FmZXRlcmlhJTIwZGluaW5nfGVufDF8fHx8MTc1OTAxNDU5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Campus canteen interior"
                className="rounded-lg shadow-lg w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Story</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              What started as a small canteen serving basic meals has grown into a beloved 
              campus institution, thanks to our commitment to quality and student satisfaction.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Our Mission</h3>
                <p className="text-gray-600">
                  To provide students with healthy, delicious, and affordable meals that fuel 
                  their academic journey. We believe good food is essential for good learning, 
                  and we're committed to making nutritious meals accessible to every student.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Our Values</h3>
                <ul className="text-gray-600 space-y-2">
                  <li>• Fresh ingredients sourced daily</li>
                  <li>• Hygienic food preparation standards</li>
                  <li>• Student-friendly pricing</li>
                  <li>• Authentic Indian flavors</li>
                  <li>• Quick service for busy schedules</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact & Hours */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Visit Us</h2>
            <p className="text-lg text-gray-600">
              Find us on campus or get in touch with any questions
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Location */}
            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Location</h3>
                <p className="text-gray-600">
                  Ground Floor, Student Center<br />
                  Main Campus Building<br />
                  University Road, Campus
                </p>
              </CardContent>
            </Card>
            
            {/* Contact */}
            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Contact</h3>
                <p className="text-gray-600 mb-2">
                  <Phone className="w-4 h-4 inline mr-2" />
                  +91 98765 43210
                </p>
                <p className="text-gray-600">
                  <Mail className="w-4 h-4 inline mr-2" />
                  canteen@university.edu
                </p>
              </CardContent>
            </Card>
            
            {/* Hours */}
            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Hours</h3>
                <div className="space-y-2 text-gray-600">
                  {hours.map((schedule, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>{schedule.day}</span>
                      <span>{schedule.time}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Special Note */}
          <div className="mt-12 text-center bg-primary/5 rounded-lg p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Special Note</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We're constantly working to improve our menu and service. If you have any 
              suggestions or feedback, please don't hesitate to reach out. Your input 
              helps us serve you better!
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

  # College Canteen Food Order System

  This is a code bundle for College Canteen Food Order System. The original project is available at https://www.figma.com/design/Fmk4dMnWeMtzH9P6neCgkW/College-Canteen-Food-Order-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  